/* Compiler:  	GNU
 *
 * Date:      	23. 11. 2012
 * Author:    	Imed Bahrini
 *				Edris Taieb
 *				Florian Schlosser
 *
 *          	HAW-Hamburg
 *              Labor f�r technische Informatik
 *            	Berliner Tor  7
 *            	D-20099 Hamburg
 ********************************************************************
 * Description:
 *
 * - main program
 ********************************************************************
 * History:
 *
 *     Initial revision 
 ********************************************************************/

#include "header.h"
#include "SPI.h"
#include "updownload.h"

void init_stick();

int main(void) {
    
	// initialize stick and fast GPIO
    init_stick();

	// initialize SPI
	init_spi();

	// read device ID from SPI
	int id = get_device_ID();
    printf("dev ID: %x\n", id);


    while (1){}
}

void init_stick() {
 	BaseStickConfig();
    SCS |= 1;              //Umschalten von Port0 und Port1 auf Fast GPIO
    FIO0DIR = TI_FIO0DIR;  //Setzen der Richtungsbits
    FIO1DIR = TI_FIO1DIR;
}

/************************************** EOF *********************************/
